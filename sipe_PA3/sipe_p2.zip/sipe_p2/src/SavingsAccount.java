public class SavingsAccount
{
    private static double annualInterestRate;
    private double savingsBalance;

    public void calculateMonthlyInterest(double savingsBal, double annualIRate)
    {
        double monthlyInterest = (savingsBal * annualIRate) / 12.0;
        savingsBalance += monthlyInterest;
    }

    public static void modifyInterestRate(double annualIRate)
    {
        annualInterestRate = annualIRate;
    }

    public void setAmount(double amount)
    {
        savingsBalance = amount;
    }

    public double getSavingsAmt()
    {
        return savingsBalance;
    }

    public void print()
    {
        System.out.println("Savings Balance: " + savingsBalance);
    }

    public static void main(String[] args)
    {
        SavingsAccount saver1 = new SavingsAccount();
        SavingsAccount saver2 = new SavingsAccount();

        saver1.setAmount(2000.0);
        saver2.setAmount(3000.0);

        saver1.modifyInterestRate(0.04);
        saver2.modifyInterestRate(0.04);

        System.out.println("For saver1:");
        for (int i = 0; i < 12; i++)
        {
            saver1.calculateMonthlyInterest(saver1.getSavingsAmt(), 0.04);
            System.out.println("Month #" + (i + 1));
            saver1.print();
        }

        System.out.println("For saver2:");
        for (int i = 0; i < 12; i++)
        {
            saver2.calculateMonthlyInterest(saver2.getSavingsAmt(), 0.04);
            System.out.println("Month #" + (i + 1));
            saver2.print();
        }

        saver1.calculateMonthlyInterest(saver1.getSavingsAmt(), 0.05);
        saver2.calculateMonthlyInterest(saver2.getSavingsAmt(), 0.05);

        System.out.print("Additional month for saver1, balance is: ");
        saver1.print();
        System.out.print("Additional month for saver2, balance is: ");
        saver2.print();
    }
}

