package com.company;
import java.util.Scanner;
import java.security.SecureRandom;

public class Main
{
    public static void questionGen(int rand1, int rand2, int type)
    {
        System.out.print("How much is ");
        if (type == 1)
        {
            System.out.println(rand1 + " plus " + rand2 + "?");
        }
        else if (type == 2)
        {
            System.out.println(rand1 + " times " + rand2 + "?");
        }
        else if (type == 3)
        {
            System.out.println(rand1 + " minus " + rand2 + "?");
        }
        else if (type == 4)
        {
            System.out.println(rand1 + " divided by " + rand2 + "?");
        }
    }

    public static void userChoice()
    {
        System.out.println("Please enter a difficulty level:");
        System.out.println("Enter 1 for single digit numbers.");
        System.out.println("Enter 2 for two digit numbers.");
        System.out.println("Enter 3 for three digit numbers.");
        System.out.println("Enter 4 for four digit numbers.");
    }

    public static int randFunction(int userChoice, SecureRandom rand)
    {
        int randomNum = 0;
        if (userChoice == 1)
        {
            randomNum = rand.nextInt(10);
        }
        else if (userChoice == 2)
        {
            randomNum = rand.nextInt(100);
        }
        else if (userChoice == 3)
        {
            randomNum = rand.nextInt(1000);
        }
        else if (userChoice == 4)
        {
            randomNum = rand.nextInt(10000);
        }

        return randomNum;
    }

    public static void additionProblems(Scanner scnr, SecureRandom rand)
    {
        int i, userInput = 0, difficultyLevel, var1, var2, sum = 0, successCount = 0;
        double percentageScore = 0;

        userChoice();
        difficultyLevel = scnr.nextInt();

        for (i = 0; i < 10; i++)
        {
            var1 = randFunction(difficultyLevel, rand);
            var2 = randFunction(difficultyLevel, rand);
            questionGen(var1, var2, 1);
            sum = var1 + var2;
            userInput = scnr.nextInt();

            if (userInput == sum)
            {
                successCount++;
            }
        }

        percentageScore = successCount / 10.0;
        if (percentageScore >= 0.75)
        {
            System.out.println("Congratulations, you are ready to go to the next level!");
        }
        else if (percentageScore < 0.75)
        {
            System.out.println("Please ask your teacher for extra help.");
        }
    }

    public static void subtractionProblems(Scanner scnr, SecureRandom rand)
    {
        int i, userInput = 0, difficultyLevel, var1, var2, difference = 0, successCount = 0;
        double percentageScore = 0;

        userChoice();
        difficultyLevel = scnr.nextInt();

        for (i = 0; i < 10; i++)
        {
            var1 = randFunction(difficultyLevel, rand);
            var2 = randFunction(difficultyLevel, rand);
            questionGen(var1, var2, 3);
            difference = var1 - var2;
            userInput = scnr.nextInt();

            if (userInput == difference)
            {
                successCount++;
            }
        }

        percentageScore = successCount / 10.0;
        if (percentageScore >= 0.75)
        {
            System.out.println("Congratulations, you are ready to go to the next level!");
        }
        else if (percentageScore < 0.75)
        {
            System.out.println("Please ask your teacher for extra help.");
        }
    }

    public static void multiplicationProblems(Scanner scnr, SecureRandom rand)
    {
        int i, userInput = 0, difficultyLevel, var1, var2, product = 0, successCount = 0;
        double percentageScore = 0;

        userChoice();
        difficultyLevel = scnr.nextInt();

        for (i = 0; i < 10; i++)
        {
            var1 = randFunction(difficultyLevel, rand);
            var2 = randFunction(difficultyLevel, rand);
            questionGen(var1, var2, 2);
            product = var1 * var2;
            userInput = scnr.nextInt();

            if (userInput == product)
            {
                successCount++;
            }
        }

        percentageScore = successCount / 10.0;
        if (percentageScore >= 0.75)
        {
            System.out.println("Congratulations, you are ready to go to the next level!");
        }
        else if (percentageScore < 0.75)
        {
            System.out.println("Please ask your teacher for extra help.");
        }
    }

    public static void divisionProblems(Scanner scnr, SecureRandom rand)
    {
        int i, difficultyLevel, successCount = 0;
        double percentageScore = 0, userInput = 0,  var1, var2, quotient = 0;

        userChoice();
        difficultyLevel = scnr.nextInt();

        for (i = 0; i < 10; i++)
        {
            var1 = randFunction(difficultyLevel, rand);
            var2 = randFunction(difficultyLevel, rand);
            if (var1 > var2)
            {
                questionGen((int)var1, (int)var2, 4);
                quotient = var1 / var2;
            }
            else if (var2 > var1)
            {
                questionGen((int)var1, (int)var2, 4);
                quotient = var2 / var1;
            }

            userInput = scnr.nextInt();

            if (userInput == quotient)
            {
                successCount++;
            }
        }

        percentageScore = successCount / 10.0;
        if (percentageScore >= 0.75)
        {
            System.out.println("Congratulations, you are ready to go to the next level!");
        }
        else if (percentageScore < 0.75)
        {
            System.out.println("Please ask your teacher for extra help.");
        }
    }

    public static void mixedProblems(Scanner scnr, SecureRandom rand)
    {
        int i, difficultyLevel, successCount = 0, typeSelect = 0, product = 0, sum = 0, difference = 0, var1, var2;
        double percentageScore = 0, userInput = 0, quotient = 0;

        userChoice();
        difficultyLevel = scnr.nextInt();

        for (i = 0; i < 10; i++)
        {
            var1 = randFunction(difficultyLevel, rand);
            var2 = randFunction(difficultyLevel, rand);
            typeSelect = rand.nextInt(4);

            if (typeSelect == 0)
            {
                questionGen(var1, var2, 1);
                sum = var1 + var2;
                userInput = scnr.nextInt();

                if (userInput == sum)
                {
                    successCount++;
                }
            }
            else if (typeSelect == 1)
            {
                questionGen(var1, var2, 2);
                product = var1 * var2;
                userInput = scnr.nextInt();

                if (userInput == product)
                {
                    successCount++;
                }
            }
            else if (typeSelect == 2)
            {
                questionGen(var1, var2, 3);
                difference = var1 - var2;
                userInput = scnr.nextInt();

                if (userInput == difference)
                {
                    successCount++;
                }
            }
            else if (typeSelect == 3)
            {
                if (var1 > var2)
                {
                    questionGen(var1, var2, 4);
                    quotient = (double)var1 / (double)var2;
                }
                else if (var2 > var1)
                {
                    questionGen(var1, var2, 4);
                    quotient = (double)var2 / (double)var1;
                }

                if (userInput == quotient)
                {
                    successCount++;
                }
            }
        }
        System.out.println(successCount);
        percentageScore = successCount / 10.0;
        if (percentageScore >= 0.75)
        {
            System.out.println("Congratulations, you are ready to go to the next level!");
        }
        else if (percentageScore < 0.75)
        {
            System.out.println("Please ask your teacher for extra help.");
        }
    }

    public static void main(String[] args) {
        int i, userGuess, product, difficultyLevel, flag = 1;
        int rand1, rand2, successRandom, successCount = 0, userEntry;
        double percentageScore = 0;
        String userInput = "";
        Scanner scnr = new Scanner(System.in);
        SecureRandom rand = new SecureRandom();

        System.out.println("Please pick a type of arithmetic problem to study:");
        System.out.println("If addition, enter 1.");
        System.out.println("If multiplication, enter 2.");
        System.out.println("If subtraction, enter 3.");
        System.out.println("If division, enter 4.");
        System.out.println("If you'd like a mix of all 4, enter 5.");

        userEntry = scnr.nextInt();

        while (flag == 1)
        {
            if (userEntry == 1)
            {
                additionProblems(scnr, rand);
            }
            else if (userEntry == 2)
            {
                multiplicationProblems(scnr, rand);
            }
            else if (userEntry == 3)
            {
                subtractionProblems(scnr, rand);
            }
            else if (userEntry == 4)
            {
                divisionProblems(scnr, rand);
            }
            else if (userEntry == 5)
            {
                mixedProblems(scnr, rand);
            }

            System.out.println("Would you like to try again?");
            System.out.println("Enter y for yes and n for no.");
            userInput = scnr.next();
            if (userInput.compareTo("y") == 0)
            {
                flag = 1;
            }
            else if (userInput.compareTo("n") == 0)
            {
                flag = 0;
            }
        }
    }
}
